# Q U E E N 👑

# Components

contains the components of the application.

# What is a component ?

a component is a widget that contains

- ZERO LOGIC
- ZERO STATE-Managment
- ZERO Anything but UI CODE
