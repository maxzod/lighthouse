// * # Q U E E N  👑
class ThemeConfig {
  ThemeConfig._();

  static const lightTheme = '';

  static const darkTheme = '';
}
