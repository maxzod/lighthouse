// * # Q U E E N  👑
class ApiRoutesConfig {
  ApiRoutesConfig._();
}
