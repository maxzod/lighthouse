// * # Q U E E N  👑
class KeysConfig {
  KeysConfig._();
}
